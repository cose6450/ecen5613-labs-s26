/*
 * Author Nalin Saxena & Colin Sergi
 * ECEN 5613 - Spring 2026 - Prof. McClure
 * University of Colorado Boulder
 * Date Created 2/21/26
 *  --------------------------------------------------------------------------------
 *  A file to implement a terminal program allocating and freeing buffers
   ---------------------------------------------------------------------------------*/

#include "my_serial.h"
#include <stdio.h>
#include <mcs51/8051.h>
#include <at89c51ed2.h>
#include <stdlib.h>
#include <stdbool.h>
#include "input.h"
#include "string.h"
#include "heap.h"
#include "linked_list.h"
#include "allocation.h"
#include "debug.h"
#include "eeprom.h"
/*
[Important Note] if you have made this change via paulmon2 you can comment this section

setting all 1024 of internal xram
*/
int _sdcc_external_startup()
{
    // AUXR |= 0X0C; implemented in paulmon
    return 0;
}

extern __xdata char __sdcc_heap[HEAP_SIZE];




void main()
{
    eeprom_init();
    eepromwritebyte(0x5F, 0x4F);
    uint8_t byte = 0x00; 
    eepromreadbyte(0x5F, &byte);
    if (byte == 0x4F)
    {
        P1_1 = 0;
        printf("Success\r\n");
    }
    else
    {
        P1_0;
        printf("Failure\r\n");
    }
    for(;;)
    {
        // printf("\r\nEnter a char: ");
        // switch(received_char)
        // {
        //     default:
        //         continue; //no command, don't print the end command line
        // }
        // printf("\r\nEND COMMAND");
        // print_dashed_line();
    }
}